package com.example.release_ready_flutter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
