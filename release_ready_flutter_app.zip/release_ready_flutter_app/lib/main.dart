import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(const WeatherApp());
}

class WeatherApp extends StatelessWidget {
  const WeatherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SkyView Weather',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1E3A5F)),
        useMaterial3: true,
        fontFamily: 'sans-serif',
      ),
      home: const WeatherScreen(),
    );
  }
}

class WeatherData {
  final String city;
  final double temperature;
  final double feelsLike;
  final int humidity;
  final double windSpeed;
  final int weatherCode;
  final bool isDay;

  WeatherData({
    required this.city,
    required this.temperature,
    required this.feelsLike,
    required this.humidity,
    required this.windSpeed,
    required this.weatherCode,
    required this.isDay,
  });
}

class WeatherScreen extends StatefulWidget {
  const WeatherScreen({super.key});

  @override
  State<WeatherScreen> createState() => _WeatherScreenState();
}

class _WeatherScreenState extends State<WeatherScreen> {
  final TextEditingController _searchController = TextEditingController();
  WeatherData? _weatherData;
  bool _isLoading = false;
  String? _error;

  // City coordinates map
  final Map<String, Map<String, double>> _cities = {
    'Astana': {'lat': 51.1801, 'lon': 71.4460},
    'Almaty': {'lat': 43.2220, 'lon': 76.8512},
    'London': {'lat': 51.5074, 'lon': -0.1278},
    'New York': {'lat': 40.7128, 'lon': -74.0060},
    'Tokyo': {'lat': 35.6762, 'lon': 139.6503},
    'Paris': {'lat': 48.8566, 'lon': 2.3522},
    'Dubai': {'lat': 25.2048, 'lon': 55.2708},
    'Moscow': {'lat': 55.7558, 'lon': 37.6173},
    'Istanbul': {'lat': 41.0082, 'lon': 28.9784},
    'Berlin': {'lat': 52.5200, 'lon': 13.4050},
  };

  Future<void> _fetchWeather(String cityName) async {
    final coords = _cities.entries
        .firstWhere(
          (e) => e.key.toLowerCase() == cityName.toLowerCase(),
          orElse: () => const MapEntry('', {}),
        )
        .value;

    if (coords.isEmpty) {
      setState(() {
        _error = 'City not found. Try: ${_cities.keys.join(", ")}';
        _isLoading = false;
      });
      return;
    }

    final lat = coords['lat']!;
    final lon = coords['lon']!;

    final url = Uri.parse(
      'https://api.open-meteo.com/v1/forecast'
      '?latitude=$lat&longitude=$lon'
      '&current=temperature_2m,apparent_temperature,relative_humidity_2m,'
      'wind_speed_10m,weather_code,is_day'
      '&wind_speed_unit=ms',
    );

    final response = await http.get(url);
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final current = data['current'];
      setState(() {
        _weatherData = WeatherData(
          city: cityName,
          temperature: (current['temperature_2m'] as num).toDouble(),
          feelsLike: (current['apparent_temperature'] as num).toDouble(),
          humidity: current['relative_humidity_2m'] as int,
          windSpeed: (current['wind_speed_10m'] as num).toDouble(),
          weatherCode: current['weather_code'] as int,
          isDay: current['is_day'] == 1,
        );
        _error = null;
        _isLoading = false;
      });
    } else {
      setState(() {
        _error = 'Failed to fetch weather data';
        _isLoading = false;
      });
    }
  }

  void _search() {
    final city = _searchController.text.trim();
    if (city.isEmpty) return;
    setState(() {
      _isLoading = true;
      _error = null;
    });
    _fetchWeather(city);
  }

  String _getWeatherIcon(int code, bool isDay) {
    if (code == 0) return isDay ? '☀️' : '🌙';
    if (code <= 2) return isDay ? '⛅' : '🌤️';
    if (code == 3) return '☁️';
    if (code <= 49) return '🌫️';
    if (code <= 59) return '🌦️';
    if (code <= 69) return '🌧️';
    if (code <= 79) return '❄️';
    if (code <= 84) return '🌧️';
    if (code <= 94) return '⛈️';
    return '🌩️';
  }

  String _getWeatherDescription(int code) {
    if (code == 0) return 'Clear Sky';
    if (code <= 2) return 'Partly Cloudy';
    if (code == 3) return 'Overcast';
    if (code <= 49) return 'Foggy';
    if (code <= 59) return 'Drizzle';
    if (code <= 69) return 'Rainy';
    if (code <= 79) return 'Snowy';
    if (code <= 84) return 'Rain Showers';
    if (code <= 94) return 'Thunderstorm';
    return 'Stormy';
  }

  List<Color> _getGradient(int code, bool isDay) {
    if (!isDay) return [const Color(0xFF0D1B2A), const Color(0xFF1B2A4A)];
    if (code == 0) return [const Color(0xFF1E88E5), const Color(0xFF42A5F5)];
    if (code <= 2) return [const Color(0xFF1565C0), const Color(0xFF5C9BD6)];
    if (code <= 49) return [const Color(0xFF546E7A), const Color(0xFF90A4AE)];
    return [const Color(0xFF37474F), const Color(0xFF607D8B)];
  }

  @override
  Widget build(BuildContext context) {
    final gradient = _weatherData != null
        ? _getGradient(_weatherData!.weatherCode, _weatherData!.isDay)
        : [const Color(0xFF1E3A5F), const Color(0xFF2E5F9F)];

    return Scaffold(
      body: AnimatedContainer(
        duration: const Duration(milliseconds: 800),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: gradient,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 24),
              // Title
              const Text(
                'SkyView',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 4),
              const Text(
                'Weather Forecast',
                style: TextStyle(
                  color: Colors.white60,
                  fontSize: 14,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 24),

              // Search Bar
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _searchController,
                        onSubmitted: (_) => _search(),
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Search city...',
                          hintStyle: const TextStyle(color: Colors.white54),
                          prefixIcon: const Icon(Icons.search, color: Colors.white54),
                          filled: true,
                          fillColor: Colors.white12,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(16),
                            borderSide: BorderSide.none,
                          ),
                          contentPadding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    ElevatedButton(
                      onPressed: _search,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white24,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.all(14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 0,
                      ),
                      child: const Icon(Icons.arrow_forward),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 12),
              // Quick city chips
              SizedBox(
                height: 36,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  children: ['Astana', 'Almaty', 'London', 'Tokyo', 'Dubai']
                      .map((city) => Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: GestureDetector(
                              onTap: () {
                                _searchController.text = city;
                                _search();
                              },
                              child: Chip(
                                label: Text(city,
                                    style: const TextStyle(
                                        color: Colors.white, fontSize: 12)),
                                backgroundColor: Colors.white.withOpacity(0.15),
                                side: BorderSide.none,
                                padding: EdgeInsets.zero,
                              ),
                            ),
                          ))
                      .toList(),
                ),
              ),

              const SizedBox(height: 24),
              Expanded(
                child: _isLoading
                    ? const Center(
                        child: CircularProgressIndicator(color: Colors.white))
                    : _error != null
                        ? Center(
                            child: Padding(
                              padding: const EdgeInsets.all(24),
                              child: Text(_error!,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(
                                      color: Colors.white70, fontSize: 16)),
                            ),
                          )
                        : _weatherData == null
                            ? const Center(
                                child: Text(
                                  'Search for a city\nto see the weather ☁️',
                                  textAlign: TextAlign.center,
                                  style: TextStyle(
                                      color: Colors.white60, fontSize: 18),
                                ),
                              )
                            : _buildWeatherCard(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildWeatherCard() {
    final w = _weatherData!;
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        children: [
          // Main card
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: Colors.white12,
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: Colors.white24),
            ),
            child: Column(
              children: [
                Text(w.city,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.w600)),
                const SizedBox(height: 16),
                Text(
                  _getWeatherIcon(w.weatherCode, w.isDay),
                  style: const TextStyle(fontSize: 80),
                ),
                const SizedBox(height: 16),
                Text(
                  '${w.temperature.round()}°C',
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 64,
                      fontWeight: FontWeight.bold),
                ),
                Text(
                  _getWeatherDescription(w.weatherCode),
                  style: const TextStyle(color: Colors.white70, fontSize: 18),
                ),
                const SizedBox(height: 8),
                Text(
                  'Feels like ${w.feelsLike.round()}°C',
                  style: const TextStyle(color: Colors.white54, fontSize: 14),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          // Stats row
          Row(
            children: [
              _statCard('💧', 'Humidity', '${w.humidity}%'),
              const SizedBox(width: 12),
              _statCard('💨', 'Wind', '${w.windSpeed.toStringAsFixed(1)} m/s'),
              const SizedBox(width: 12),
              _statCard(w.isDay ? '🌞' : '🌙', 'Time', w.isDay ? 'Day' : 'Night'),
            ],
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  Widget _statCard(String icon, String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white12,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white24),
        ),
        child: Column(
          children: [
            Text(icon, style: const TextStyle(fontSize: 24)),
            const SizedBox(height: 8),
            Text(value,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.bold)),
            Text(label,
                style: const TextStyle(color: Colors.white54, fontSize: 11)),
          ],
        ),
      ),
    );
  }
}